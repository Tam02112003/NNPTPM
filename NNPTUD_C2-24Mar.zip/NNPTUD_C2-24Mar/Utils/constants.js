module.exports={
    SECRET_KEY:"NNPTUD_C2",
    MOD_PERMISSION: ['mod','admin'],
    ADMIN_PERMISSION: ['admin'],
    USER_PERMISSION: ['user','mod','admin'],
    EMAIL_ERROR:"email phai dang xxxx@domain",
    PASSWORD_ERROR:"password can dai hon %d ki tu, co it nhat %d chu thuong, %d chu hoa, %d ki tu va co %d so"
}